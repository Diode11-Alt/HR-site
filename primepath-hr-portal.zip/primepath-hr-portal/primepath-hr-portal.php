<?php
/**
 * Plugin Name: PrimePath HR Portal
 * Description: Transforms WordPress into a fully-functional Recruitment & HR Portal. Includes Job Board, Employer Dashboards, Seeker Dashboards, and Inquiry Management.
 * Version: 1.0.0
 * Author: PrimePath
 */

if (!defined('ABSPATH')) {
    exit;
}

// =========================================================
// 1. ACTIVATION & DATABASE SETUP
// =========================================================
register_activation_hook(__FILE__, 'pp_hr_activate');
function pp_hr_activate() {
    // 1. Create Inquiry Table
    global $wpdb;
    $table_name = $wpdb->prefix . 'primepath_inquiries';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        time datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
        subject text NOT NULL,
        sender text NOT NULL,
        message longtext NOT NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

    // 2. Add Roles
    add_role('pp_employer', 'Employer', [
        'read' => true,
        'upload_files' => true
    ]);
    
    add_role('pp_job_seeker', 'Job Seeker', [
        'read' => true,
        'upload_files' => true
    ]);

    // 3. Flush Rewrite Rules
    pp_register_post_types();
    flush_rewrite_rules();
}

// =========================================================
// 2. CUSTOM POST TYPES
// =========================================================
add_action('init', 'pp_register_post_types');
function pp_register_post_types() {
    // Job Postings
    register_post_type('pp_job_posting', [
        'labels' => [
            'name' => 'Job Postings',
            'singular_name' => 'Job Posting'
        ],
        'public' => true,
        'has_archive' => true,
        'supports' => ['title', 'editor', 'author', 'custom-fields'],
        'menu_icon' => 'dashicons-portfolio',
        'show_in_rest' => true
    ]);

    // Job Applications
    register_post_type('pp_application', [
        'labels' => [
            'name' => 'Applications',
            'singular_name' => 'Application'
        ],
        'public' => false,
        'show_ui' => true,
        'supports' => ['title', 'author', 'custom-fields'],
        'menu_icon' => 'dashicons-id',
    ]);
}

// =========================================================
// 3. INQUIRY CAPTURE (From previous plugin)
// =========================================================
add_filter('wp_mail', 'pp_capture_inquiry');
function pp_capture_inquiry($args) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'primepath_inquiries';
    $to = is_array($args['to']) ? implode(', ', $args['to']) : $args['to'];
    $subject = $args['subject'];
    $message = is_array($args['message']) ? implode("\n", $args['message']) : $args['message'];
    
    $wpdb->insert($table_name, [
        'time' => current_time('mysql'),
        'subject' => $subject,
        'sender' => $to,
        'message' => $message
    ]);
    return $args;
}

// =========================================================
// 4. ADMIN INQUIRY DASHBOARD
// =========================================================
add_action('admin_menu', 'pp_add_admin_menu');
function pp_add_admin_menu() {
    add_menu_page('Inquiries', 'Inquiries', 'manage_options', 'primepath-inquiries', 'pp_inquiries_page', 'dashicons-email', 6);
}

function pp_inquiries_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'primepath_inquiries';
    $inquiries = $wpdb->get_results("SELECT * FROM $table_name ORDER BY time DESC LIMIT 200");
    
    echo '<div class="wrap"><h1>Captured Inquiries</h1><table class="wp-list-table widefat fixed striped">';
    echo '<thead><tr><th>Date</th><th>Sent To</th><th>Subject</th><th>Message</th></tr></thead><tbody>';
    if (empty($inquiries)) {
        echo '<tr><td colspan="4">No inquiries found.</td></tr>';
    } else {
        foreach ($inquiries as $inq) {
            echo '<tr><td>'.esc_html($inq->time).'</td><td>'.esc_html($inq->sender).'</td><td>'.esc_html($inq->subject).'</td><td>'.nl2br(esc_html($inq->message)).'</td></tr>';
        }
    }
    echo '</tbody></table></div>';
}

// =========================================================
// 5. SHORTCODES: PUBLIC JOB BOARD
// =========================================================
add_shortcode('pp_job_board', 'pp_job_board_sc');
function pp_job_board_sc() {
    ob_start();
    $jobs = new WP_Query([
        'post_type' => 'pp_job_posting',
        'post_status' => 'publish',
        'posts_per_page' => 20
    ]);
    
    echo '<div class="pp-job-board">';
    if($jobs->have_posts()){
        while($jobs->have_posts()){
            $jobs->the_post();
            $location = get_post_meta(get_the_ID(), 'pp_location', true);
            $salary = get_post_meta(get_the_ID(), 'pp_salary', true);
            
            echo '<div style="border: 1px solid #ccc; padding: 15px; margin-bottom: 15px; border-radius: 5px;">';
            echo '<h3>' . get_the_title() . '</h3>';
            echo '<strong>Location:</strong> ' . esc_html($location) . ' | <strong>Salary:</strong> ' . esc_html($salary) . '<br><br>';
            echo '<a href="'.get_permalink().'" style="background: #0A2540; color: white; padding: 8px 15px; text-decoration: none; border-radius: 3px;">View Details & Apply</a>';
            echo '</div>';
        }
        wp_reset_postdata();
    } else {
        echo '<p>No jobs available at the moment.</p>';
    }
    echo '</div>';
    return ob_get_clean();
}

// =========================================================
// 6. SHORTCODES: EMPLOYER DASHBOARD
// =========================================================
add_shortcode('pp_employer_dashboard', 'pp_employer_dashboard_sc');
function pp_employer_dashboard_sc() {
    if (!is_user_logged_in() || !current_user_can('pp_employer') && !current_user_can('administrator')) {
        return '<p>You must be logged in as an Employer to view this portal.</p>';
    }
    
    $current_user = wp_get_current_user();
    ob_start();
    
    // Handle job submission
    if(isset($_POST['pp_submit_job'])) {
        $job_title = sanitize_text_field($_POST['job_title']);
        $job_desc = sanitize_textarea_field($_POST['job_desc']);
        $job_location = sanitize_text_field($_POST['job_location']);
        $job_salary = sanitize_text_field($_POST['job_salary']);
        
        $post_id = wp_insert_post([
            'post_title' => $job_title,
            'post_content' => $job_desc,
            'post_status' => 'pending', // Requires admin approval
            'post_type' => 'pp_job_posting',
            'post_author' => $current_user->ID
        ]);
        
        if($post_id) {
            update_post_meta($post_id, 'pp_location', $job_location);
            update_post_meta($post_id, 'pp_salary', $job_salary);
            echo '<div style="color: green; font-weight: bold; margin-bottom: 15px;">Job submitted successfully! It is pending admin approval.</div>';
        }
    }
    
    ?>
    <div class="pp-dashboard" style="background: #f9f9f9; padding: 20px; border-radius: 8px;">
        <h2>Welcome, <?php echo esc_html($current_user->display_name); ?></h2>
        <hr>
        
        <h3>Post a New Job</h3>
        <form method="POST" style="margin-bottom: 30px;">
            <p><label>Job Title:</label><br><input type="text" name="job_title" required style="width: 100%;"></p>
            <p><label>Location:</label><br><input type="text" name="job_location" style="width: 100%;"></p>
            <p><label>Salary Range:</label><br><input type="text" name="job_salary" style="width: 100%;"></p>
            <p><label>Job Description:</label><br><textarea name="job_desc" required style="width: 100%; height: 100px;"></textarea></p>
            <p><button type="submit" name="pp_submit_job" style="background: #0A2540; color: white; border: none; padding: 10px 20px; cursor: pointer;">Post Job (Pending Approval)</button></p>
        </form>

        <h3>Your Posted Jobs & Applicants</h3>
        <?php
        $my_jobs = new WP_Query([
            'post_type' => 'pp_job_posting',
            'author' => $current_user->ID,
            'post_status' => ['publish', 'pending'],
            'posts_per_page' => -1
        ]);
        
        if($my_jobs->have_posts()) {
            echo '<table style="width: 100%; border-collapse: collapse;">';
            echo '<tr style="background: #e0e0e0; text-align: left;"><th style="padding: 10px;">Job Title</th><th>Status</th><th>Applicants</th></tr>';
            while($my_jobs->have_posts()) {
                $my_jobs->the_post();
                $job_id = get_the_ID();
                
                // Count applicants
                $applicants = new WP_Query([
                    'post_type' => 'pp_application',
                    'meta_key' => 'pp_job_id',
                    'meta_value' => $job_id,
                    'posts_per_page' => -1
                ]);
                $count = $applicants->found_posts;
                
                echo '<tr style="border-bottom: 1px solid #ccc;">';
                echo '<td style="padding: 10px;">' . get_the_title() . '</td>';
                echo '<td>' . get_post_status() . '</td>';
                echo '<td>' . $count . ' candidates</td>';
                echo '</tr>';
            }
            echo '</table>';
        } else {
            echo '<p>You have not posted any jobs yet.</p>';
        }
        ?>
    </div>
    <?php
    return ob_get_clean();
}

// =========================================================
// 7. SHORTCODES: JOB SEEKER DASHBOARD & APPLY
// =========================================================
// Automatically append application form to single job posting pages
add_filter('the_content', 'pp_append_apply_form');
function pp_append_apply_form($content) {
    if (is_singular('pp_job_posting')) {
        $form = pp_apply_job_form(get_the_ID());
        return $content . $form;
    }
    return $content;
}

function pp_apply_job_form($job_id) {
    if(isset($_POST['pp_submit_application'])) {
        $app_name = sanitize_text_field($_POST['app_name']);
        $app_email = sanitize_email($_POST['app_email']);
        $app_phone = sanitize_text_field($_POST['app_phone']);
        $app_cover = sanitize_textarea_field($_POST['app_cover']);
        
        // Create Application Post
        $post_id = wp_insert_post([
            'post_title' => 'App: ' . $app_name . ' for Job #' . $job_id,
            'post_content' => $app_cover,
            'post_status' => 'publish',
            'post_type' => 'pp_application'
        ]);
        
        if($post_id) {
            update_post_meta($post_id, 'pp_job_id', $job_id);
            update_post_meta($post_id, 'pp_applicant_email', $app_email);
            update_post_meta($post_id, 'pp_applicant_phone', $app_phone);
            
            // Handle CV Upload (simplified)
            if(!function_exists('wp_handle_upload')) {
                require_once(ABSPATH . 'wp-admin/includes/file.php');
            }
            $uploadedfile = $_FILES['app_cv'];
            $upload_overrides = array('test_form' => false);
            $movefile = wp_handle_upload($uploadedfile, $upload_overrides);
            if($movefile && !isset($movefile['error'])) {
                update_post_meta($post_id, 'pp_cv_url', $movefile['url']);
            }
            
            return '<div style="background: #d4edda; color: #155724; padding: 15px; border-radius: 5px;">Thank you! Your application has been submitted successfully.</div>';
        }
    }

    ob_start();
    ?>
    <div style="background: #f4f4f4; padding: 25px; margin-top: 40px; border-radius: 8px;">
        <h3>Apply for this Position</h3>
        <form method="POST" enctype="multipart/form-data">
            <p><label>Full Name:</label><br><input type="text" name="app_name" required style="width: 100%;"></p>
            <p><label>Email Address:</label><br><input type="email" name="app_email" required style="width: 100%;"></p>
            <p><label>Phone Number:</label><br><input type="text" name="app_phone" required style="width: 100%;"></p>
            <p><label>Cover Letter (Optional):</label><br><textarea name="app_cover" style="width: 100%; height: 80px;"></textarea></p>
            <p><label>Upload CV (PDF/DOCX):</label><br><input type="file" name="app_cv" accept=".pdf,.doc,.docx" required></p>
            <p><button type="submit" name="pp_submit_application" style="background: #FF4B2B; color: white; border: none; padding: 10px 20px; font-weight: bold; cursor: pointer; border-radius: 4px;">Submit Application</button></p>
        </form>
    </div>
    <?php
    return ob_get_clean();
}

?>
