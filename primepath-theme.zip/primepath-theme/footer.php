</main>

<footer class="footer">
    <div class="container">
        <div class="footer-grid">
            <div class="footer-col">
                <h4>PrimePath HR</h4>
                <p>Connecting the UAE's best talent with top-tier employers through an editorial and precise recruitment process.</p>
            </div>
            <div class="footer-col">
                <h4>Portals</h4>
                <ul class="footer-links">
                    <li><a href="<?php echo esc_url( home_url( '/employer-dashboard' ) ); ?>">Employer Login</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/available-jobs' ) ); ?>">Submit CV</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Contact</h4>
                <p>Email: contact@primepathuae.com</p>
                <p>Dubai, UAE</p>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; <?php echo date('Y'); ?> PrimePath HR. All rights reserved.</p>
        </div>
    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
