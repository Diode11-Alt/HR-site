<?php get_header(); ?>

<div class="page-header" style="padding: 100px 0 60px;">
    <div class="container">
        <h1><?php single_post_title(); ?></h1>
    </div>
</div>

<div class="container section-padding" style="padding-top: 40px;">
    <?php
    if ( have_posts() ) :
        while ( have_posts() ) : the_post();
            the_content();
        endwhile;
    else :
        echo '<p>No content found.</p>';
    endif;
    ?>
</div>

<?php get_footer(); ?>
