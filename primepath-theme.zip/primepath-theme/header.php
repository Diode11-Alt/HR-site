<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<nav class="navbar">
    <div class="container">
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="logo">PrimePath<span>.</span></a>
        
        <div class="nav-links">
            <?php
            wp_nav_menu( array(
                'theme_location' => 'primary',
                'container'      => false,
                'menu_class'     => '',
                'fallback_cb'    => false,
                'items_wrap'     => '%3$s' // Removes ul wrapper to match our css
            ) );
            ?>
            <!-- Fallback if no menu is set -->
            <?php if ( ! has_nav_menu( 'primary' ) ) : ?>
                <a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a>
                <a href="<?php echo esc_url( home_url( '/available-jobs' ) ); ?>">Job Board</a>
                <a href="<?php echo esc_url( home_url( '/employer-dashboard' ) ); ?>">Employer Portal</a>
            <?php endif; ?>
        </div>
    </div>
</nav>

<main style="min-height: 80vh; padding-top: 80px;">
