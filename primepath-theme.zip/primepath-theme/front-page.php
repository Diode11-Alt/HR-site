<?php get_header(); ?>

<header class="hero">
    <div class="container">
        <div class="hero-content">
            <h1 class="animate-fade-up">Connecting UAE's Best Talent with Top Employers.</h1>
            <p class="animate-fade-up delay-100">
                An editorial approach to recruitment. We do not just fill vacancies; we architect careers and build formidable teams.
            </p>
            <div class="hero-btns animate-fade-up delay-200">
                <a href="<?php echo esc_url( home_url( '/employer-dashboard' ) ); ?>" class="btn btn-primary">I am an Employer</a>
                <a href="<?php echo esc_url( home_url( '/available-jobs' ) ); ?>" class="btn btn-outline">Find a Job</a>
            </div>
        </div>
    </div>
</header>

<section class="section-padding">
    <div class="container">
        <div class="section-title">
            <h2>Our Methodology</h2>
            <p>We blend modern technology with classic executive search techniques.</p>
        </div>
        
        <div class="grid-3">
            <div class="card">
                <div class="card-icon">
                    <svg width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
                </div>
                <h3>Executive Search</h3>
                <p>Discreetly targeting passive candidates who are the top 1% in their respective industries.</p>
            </div>
            
            <div class="card">
                <div class="card-icon">
                    <svg width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"></rect><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"></path></svg>
                </div>
                <h3>Contract Staffing</h3>
                <p>Flexible workforce solutions for project-based demands and rapid scaling.</p>
            </div>
            
            <div class="card">
                <div class="card-icon">
                    <svg width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>
                </div>
                <h3>RPO Solutions</h3>
                <p>Fully outsourcing your recruitment process to our dedicated in-house experts.</p>
            </div>
        </div>
    </div>
</section>

<?php get_footer(); ?>
