<?php get_header(); ?>

<!-- Default Page Template (Used for Job Board and Portals) -->
<div class="page-header" style="padding-bottom: 40px;">
    <div class="container">
        <h1><?php the_title(); ?></h1>
    </div>
</div>

<div class="container section-padding" style="padding-top: 40px;">
    <?php
    if ( have_posts() ) :
        while ( have_posts() ) : the_post();
            the_content();
        endwhile;
    endif;
    ?>
</div>

<?php get_footer(); ?>
