<?php
/**
 * PrimePath Theme Functions
 */

function primepath_enqueue_scripts() {
    // Enqueue Google Fonts
    wp_enqueue_style( 'primepath-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Playfair+Display:wght@600;700&display=swap', false );
    
    // Enqueue Main Stylesheet
    wp_enqueue_style( 'primepath-style', get_stylesheet_uri(), array(), wp_get_theme()->get('Version') );
}
add_action( 'wp_enqueue_scripts', 'primepath_enqueue_scripts' );

function primepath_theme_setup() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    
    // Register Menu
    register_nav_menus( array(
        'primary' => __( 'Primary Menu', 'primepath' ),
    ) );
}
add_action( 'after_setup_theme', 'primepath_theme_setup' );
